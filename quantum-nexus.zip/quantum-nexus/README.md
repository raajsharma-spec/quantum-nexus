# QUANTUM NEXUS

## From Confusion to Quantum Clarity

**AI-Assisted Interactive Quantum Learning Platform** — an MVP for Smart India Hackathon 2026
(PS ID 26140, *AI-Based Interactive Quantum Algorithm Learning Platform*, theme Smart Education,
category Software).

Learners don't just read about quantum computing. They follow one loop:

**Learn → Predict → Practice → Run → Observe → Explain → Assess → Unlock**

The signature feature is **Predict Before You Run**: Run stays locked until the learner commits to
a prediction, and the result is shown as *Your prediction* vs *What actually happened*, followed by
*Why did this happen?*

---

## 1. Run it on your computer

You need **Node.js 20.9 or newer** (the LTS version from <https://nodejs.org> is fine).

| | |
|---|---|
| **Where** | Open the `quantum-nexus` folder in VS Code, then **Terminal → New Terminal** |
| **What** | `npm install` |
| **What it does** | Downloads the libraries the project needs (one time only) |
| **What you should see** | `added … packages` and no red `ERR!` lines |
| **If it fails** | Copy the last 20 lines of the terminal output |

Then:

| | |
|---|---|
| **What** | `npm run dev` |
| **What it does** | Starts the app on your own computer |
| **What you should see** | `Local: http://localhost:3000` — open that address in your browser |
| **If it fails** | If it says the port is in use, run `npm run dev -- -p 3001` and open `http://localhost:3001` |

To stop the app, click the terminal and press `Ctrl + C`.

No API keys, no `.env` file, no database and no paid services are needed. After `npm install`,
the whole learning journey works without the internet.

---

## 2. Put it live with Vercel (free)

### Option A — from the terminal (fastest)

1. Create a free account at <https://vercel.com/signup>.
2. In the VS Code terminal, inside the `quantum-nexus` folder, run:

   ```bash
   npx vercel login
   ```

   It opens your browser to confirm the login.
3. Then run:

   ```bash
   npx vercel --prod
   ```

   Answer the questions like this:

   | Question | Answer |
   |---|---|
   | Set up and deploy? | `Y` |
   | Which scope? | Press Enter (your account) |
   | Link to existing project? | `N` |
   | What's your project's name? | `quantum-nexus` |
   | In which directory is your code located? | Press Enter (`./`) |
   | Want to modify these settings? | `N` |

   Vercel detects Next.js by itself. After about a minute it prints a
   `Production: https://quantum-nexus-….vercel.app` address. That is your live site.

To publish later changes, run `npx vercel --prod` again.

### Option B — through GitHub (no terminal after the upload)

1. Create a new empty repository at <https://github.com/new>.
2. On the repository page choose **uploading an existing file**, drag in everything inside the
   `quantum-nexus` folder **except** `node_modules` and `.next`, and commit.
3. Go to <https://vercel.com/new>, pick the repository and click **Deploy**. Keep every default.

Every later push to GitHub redeploys automatically.

---

## 3. A five-minute jury demo

1. Open the site. The landing page has a live circuit: pick a prediction, then run it.
2. **Start Learning → Use Demo Learner** shows every screen filled in (labelled **DEMO DATA**).
   For a real run instead, choose **Continue as Learner** and type a name.
3. **Dashboard** — current topic, *Your next move* with its reason, the learning loop, roadmap.
4. **Learn → Qubit Fundamentals** — concept, visual, try it, example, predict.
5. **Quantum Lab** — place `H` then `M` on `q0`, lock in the circuit, predict, run. You get ≈50/50,
   the comparison, and the explanation. Load **Bell pair** to show `CX` and entanglement.
6. **Practice → Assessment** — pass the mastery check to unlock the next topic.
7. **AI Tutor** — ask "Why was my prediction wrong?" Switch **EN / HI-ENG** in the top bar.
8. **Progress, Achievements, Educator Insights, Architecture**.
9. **Demo Reset** in the sidebar clears everything for the next judge.

---

## 4. What is real in this MVP — and what is not

| Implemented now | Not claimed |
|---|---|
| Local Educational Quantum Simulator in TypeScript: H, X, Y, Z, CX, measurement, 2 qubits | Real quantum hardware, Qiskit, cloud execution |
| Contextual AI Tutor: rule-based, uses your language, topic and last experiment | A trained AI model or any LLM API |
| Rule-Based Personalization: transparent IF → THEN rules that explain themselves | Machine learning that predicts learner behaviour |
| Local Learning Telemetry in `localStorage` | Real learner datasets, accounts or a database |
| Educator Insights with a hand-written sample cohort, labelled DEMO ANALYTICS | Real connected students |

The **Architecture** page inside the app shows the production plan (FastAPI, RAG + LLM,
PostgreSQL + pgvector, Qiskit/Aer and optional quantum backends) separately, marked as future work.

---

## 5. Where things live

```text
app/                  pages (Next.js App Router)
  page.tsx            landing page
  login/  onboarding/ entry flow
  (app)/              pages that share the sidebar and top bar:
    dashboard/ learn/ lab/ practice/ assessment/ ai-tutor/
    progress/ achievements/ educator/ architecture/
components/           reusable UI (QuantumCircuit, PredictionPanel, SimulationResult, …)
lib/
  quantumSimulator.ts the simulator: simulateCircuit, applyGate, calculateProbabilities, measureCircuit
  prediction.ts       builds the predict-before-run options for any circuit
  explain.ts          "Why did this happen?" explanations
  aiTutor.ts          the rule-based tutor
  analytics.ts        local telemetry and learner insights
  mastery.ts          mastery, unlocking and the learning-loop position
  recommendationEngine.ts   "Your next move" rules
  storage.ts  store.ts  actions.ts   localStorage and state changes
  demoSeed.ts         the illustrative Start Demo learner
data/                 lessons, mastery checks, challenges, achievements (English + Hinglish)
scripts/selftest.ts   engine checks
```

### Useful commands

| Command | What it does |
|---|---|
| `npm run dev` | Run the app while you work on it |
| `npm run build` | Build the production version (Vercel runs this for you) |
| `npm run start` | Run the production build locally |
| `npm run test:engine` | Check the simulator, mastery rules, recommendations and tutor |
| `npm run lint` | Check code style |

### Changing things

- **Mastery threshold** (default 80%): Educator Insights page, or `DEFAULT_MASTERY_THRESHOLD` in
  `lib/storage.ts`.
- **Lesson text**: `data/concepts.ts`. Each text has an `en` and a `hi` (Hinglish) version.
- **Mastery-check questions**: `data/quizzes.ts`. **Challenges**: `data/challenges.ts`.
- **Recommendation rules**: `lib/recommendationEngine.ts`.
